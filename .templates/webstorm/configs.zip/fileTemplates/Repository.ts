import { type CacheService, cacheService } from '@astraledo-web/shared';

export class ${Name}Repository {
  constructor(private readonly cache: CacheService) {}
}
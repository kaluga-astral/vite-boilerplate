import { describe, it } from '@astraledo-web/shared/_tests';

import { UIStore } from './UIStore';

describe('UIStore', () => {
  it('', () => {});
});

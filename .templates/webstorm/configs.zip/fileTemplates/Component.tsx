type ${Name}Props = {};

export const ${Name} = ({}: ${Name}Props) => {
  return ();
};

import { PageLayout } from '@example/shared';

export const ${Name}Screen = () => {
  return (
    <PageLayout
      header={{ title: '' }}
      content={{ children: null, isPaddingDisabled: false }}
    />
  );
}

import { describe, it } from '@example/shared/_tests';

import { $Name } from './$Name';

describe('$Name', () => {
  it('', () => {});
});

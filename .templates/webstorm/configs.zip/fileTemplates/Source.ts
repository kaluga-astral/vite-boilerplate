import { apiHttpClient } from '@example/shared';

import type { ${Name}NetworkSourcesDTO } from './dto';

export const ${Name}NetworkSources = {}

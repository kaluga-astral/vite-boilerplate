import { useForm } from '@example/shared';
import { type UIStore } from '../UIStore';
import { type ${Name}FormValues } from '../types';

import { validationSchema } from './validation';

export const useLogic = (store: UIStore) => {
  const form = useForm<${Name}FormValues>({
    validationSchema,
  });

  const handleFormSubmit = () => {};

  return {
    form,
    handleFormSubmit,
  };
};

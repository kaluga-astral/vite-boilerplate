import { describe, it } from '@astraledo-web/shared/_tests';

import { ${Name}Store } from './${Name}Store';

describe('${Name}Store', () => {
  it('', () => {});
});

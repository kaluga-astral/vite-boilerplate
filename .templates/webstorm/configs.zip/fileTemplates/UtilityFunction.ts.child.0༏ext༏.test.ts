import { describe, it } from '@astraledo-web/shared/_tests';

import { $Name } from './$Name';

describe('$Name', () => {
  it('', () => {});
});

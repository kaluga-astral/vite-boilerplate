import { describe, it } from '@example/shared/_tests';

import { ${Name}Store } from './${Name}Store';

describe('${Name}Store', () => {
  it('', () => {});
});

import { describe, it } from '@example/shared/_tests';

import { createCacheService } from '@example/shared';

import { ${Name}Repository } from './${Name}Repository';

describe('${Name}Repository', () => {
  it('', () => {
      const sut = new ${Name}Repository(createCacheService());
  });
});

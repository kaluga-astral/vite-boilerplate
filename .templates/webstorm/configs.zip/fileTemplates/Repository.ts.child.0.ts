import { describe, it } from '@astraledo-web/shared/_tests';

import { createCacheService } from '@astraledo-web/shared';

import { ${Name}Repository } from './${Name}Repository';

describe('${Name}Repository', () => {
  it('', () => {
      const sut = new ${Name}Repository(createCacheService());
  });
});

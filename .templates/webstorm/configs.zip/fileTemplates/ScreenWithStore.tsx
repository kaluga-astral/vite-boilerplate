import { useState } from 'react';
import { observer } from 'mobx-react-lite';

import { PageLayout } from '@astraledo-web/shared';

import { createUIStore } from './UIStore'

export const ${Name}Screen = observer(() => {
  const [store] = useState(createUIStore);

  return (
    <PageLayout
      header={{ title: '' }}
      content={{ children: null, isPaddingDisabled: false }}
    />
  );
});


import { v } from '@example/shared';

import { type ${Name}FormValues } from '../types';

export const validationSchema = v.object<${Name}FormValues>({});

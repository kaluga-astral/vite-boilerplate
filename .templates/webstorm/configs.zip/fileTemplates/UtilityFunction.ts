export const $Name = () => {

};

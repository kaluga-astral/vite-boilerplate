export namespace ${Name}RepositoryDTO {

}
